//
//  AppDelegate.h
//  CppModulesCatalystIssue
//
//  Created by Peter Steinberger on 18.03.20.
//  Copyright © 2020 PSPDFKit GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

