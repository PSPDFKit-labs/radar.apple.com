//
//  SceneDelegate.h
//  CppModulesCatalystIssue
//
//  Created by Peter Steinberger on 18.03.20.
//  Copyright © 2020 PSPDFKit GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

