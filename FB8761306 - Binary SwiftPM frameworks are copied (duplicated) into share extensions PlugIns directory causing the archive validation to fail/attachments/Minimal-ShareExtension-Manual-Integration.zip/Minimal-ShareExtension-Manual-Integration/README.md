# Setup

1. Download the latest DMG version https://customers.pspdfkit.com/download/binary/ios/latest
2. Copy `PSPDFKit.xcframework` and `PSPDFKitUI.xcframework` into this directory

